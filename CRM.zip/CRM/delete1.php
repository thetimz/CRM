<?php
require_once('connect.php');


$eid=$_GET['delid'];
// sql to delete a record
$sql = "DELETE from companies where id='$eid'";
if (mysqli_query($connection, $sql)) {
    echo "<script>alert('Successfully Deleted!'); window.location='search-company.php'</script>";
} else {
    echo "Error deleting record: " . mysqli_error($connection);
}

mysqli_close($connection);
?>