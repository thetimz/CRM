  <div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
          <ul class="nav" id="side-menu">
            <li>
              <a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Dashboard</a>
            </li>
            <li>
              <a href="companylist.php"><i class="fa fa-home nav_icon"></i>Companies<span class="fa arrow"></span> </a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="companylist.php">View Companies</a>
                </li>
                <li>
                  <a href="add-company.php">Add New Company</a>
                </li>
              </ul>
            </li>
          
           
         <li>
              <a href="add-services.php"><i class="fa fa-users nav_icon"></i>Employees<span class="fa arrow"></span> </a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="employeelist.php">View</a>
                </li>
                <li>
                  <a href="addemployee.php">Add Employees</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
            </li>
            <li>
              <a href="search-company.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search Company</a>
            </li>
             <li>
              <a href="search-employee.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search Employee</a>
            </li>
          

          </ul>
          <div class="clearfix"> </div>
          <!-- //sidebar-collapse -->
        </nav>
      </div>
    </div>