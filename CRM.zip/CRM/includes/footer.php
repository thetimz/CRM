<!--footer-->
    <div class="footer">
       <p>&copy; 2022 CRM.</p>
    </div>
        <!--//footer-->