  <?php
    session_start();
    include_once('connect.php'); 
    if(!isset($_SESSION['User']))
    {
       
    }
// Initialize the session
require_once "connect.php"; 

							
$company =mysqli_query($connection,"select * from companies  ORDER BY name");


?>

<!DOCTYPE HTML>
<html>
<head>
<title>CRM | Add Employees</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
	 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h3 class="title1">Add Employee</h3>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Employee:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="process.php">
								<p style="font-size:16px; color:red" align="center"> </p>

  
							 <div class="form-group"> 
							 	<label for="exampleInputEmail1">First Name</label> 
							 	<input type="text" class="form-control" id="name" name="firstname" placeholder="First Name" value="" required="true"> 
							 </div> 
							  <div class="form-group"> 
							 	<label for="exampleInputEmail1">Last Name</label> 
							 	<input type="text" class="form-control" id="name" name="lastname" placeholder="Last Name" value="" required="true"> 
							 </div> 


							  <div class="form-group"> 
             <label for="exampleInputEmail1">Company</label>
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="" aria-hidden="true"></i>
              </span>
              <select name="company" title="company" style="text-transform: capitalize;">
                <option value="">-- Select Company --</option>
                <?php while($rw = mysqli_fetch_assoc($company)){ ?> 
                  <option value="<?php echo $rw["name"]; ?>" <?php if(isset($editemp["name"]) && $editemp["name"]==$rw["name"]){ echo "Selected"; }?>> <?php echo $rw["name"]; ?> </option>
                <?php } ?>
              </select>
              </div>

							 	<div class="form-group"> 
							 		<label for="exampleInputPassword1">Email</label> 
							 		<input type="email" id="email" name="email" class="form-control" placeholder="Email" value="" > 
							 	</div>
							 <div class="form-group"> 
							 	<label for="exampleInputEmail1">Mobile Number</label> 
							 	<input type="number" class="form-control" id="phone" name="phone" placeholder="Mobile Number" value="" required="true"> 
							 </div>
							
							  <button type="submit" name="submit" class="btn btn-default">Add</button> </form> 
						</div>
						
					</div>
				
				
			</div>
		</div>
		 <?php include_once('includes/footer.php');?>
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>
