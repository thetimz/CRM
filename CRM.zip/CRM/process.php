<?php
require_once "connect.php";
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
    $email=$_POST['email'];
   $phone=$_POST['phone'];
    $company=$_POST['company'];

//Insert Query of SQL
$sql = "INSERT INTO employees (firstname, lastname, company, email, phone) values ('$firstname','$lastname','$company','$email','$phone')";
 $result = mysqli_query($connection, $sql) or die(mysqli_error($connection)); 
    	echo "<script>alert('Employee has been added.');</script>"; 
    		echo "<script>window.location.href = 'employeelist.php'</script>";   
    $msg="";
  }
  else
    {
    echo ('Something Went Wrong. Please try again.');  	
    }
?> 